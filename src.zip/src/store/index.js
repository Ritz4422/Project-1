import { createStore } from "redux";
import { Provider } from "react-redux";
import {App} from "./App"
import AllPost from "../AllPost";
import SearchFunctions from "../SearchFunctions";

const store = createStore(postReducer);

ReactDOM.render(
    <Provider store={store}>
        <App/>
        <SearchFunctions/>
        <Post/>
        <AllPost/>
    </Provider>
    , document.getElementById('root'));
