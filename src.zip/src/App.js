import React, { Component } from 'react';
import PostForm from './PostForm';
import AllPost from './AllPost';
import './App.css';
import SearchFunctions from './SearchFunctions';

class App extends Component {
  render() {
      return (
      <div className="App">
        <header className="App-header">
        
        <PostForm />
        <AllPost />
        </header>
      </div>
      );
  }
  }
export default App;