import React, { Component } from 'react';
import {connect} from 'react-redux';
class PostForm extends Component {
  handleSubmit = (e) => {
    e.preventDefault();
    const title = this.getTitle.value;
    const userid = this.getUserId.value;
    const rating = this.getRating.value;
    const source = this.getSource.value;
    const message =  this.getMessage.value;
    const data = {
      id: new Date(),
      title,
      userid,
      rating,
      source,
      message,
      editing:false
    }
    console.log(data)
    this.props.dispatch({type:'ADD_POST',data});
    this.getTitle.value = '';
    this.getUserId.value='';
    this.getRating.value='';
    this.getSource.value='';
    this.getMessage.value = '';
  }
render() {
return (
<div>
  <h1>Create Post</h1>
  <form onSubmit={this.handleSubmit}>
   <label>
    Title 
            <input required type="text"  ref={(input)=>this.getTitle = input} 
              placeholder="Enter Post Title"/>
    </label>
   <br /><br />

   <label>
     User ID
   <input required type="text" ref={(input)=>this.getUserId = input} 
    placeholder="Enter User Id"/>
    </label>
   <br /><br />

   <labele>
     Source
   <input required type="text" ref={(input)=>this.getSource = input} 
    placeholder="Enter Source Application"/>
    </labele>
   <br /><br />
   <labele>
     Rating
   <input required type="text" ref={(input)=>this.getRating = input} 
    placeholder="Enter Rating 1 to 5"/>
    </labele>
   <br /><br />
   <labele>
     Review
   <textarea required rows="5" ref={(input)=>this.getMessage = input} cols="50" 
    placeholder="Enter Post" />
    </labele>
   <br /><br />

   <button>Post</button>
  </form>
</div>
);
}
}
export default  connect()(PostForm);