import React, { Component } from 'react';
import {connect} from 'react-redux';
import Post from './Post';

class Search extends Component {
  render() {
  return (
    <div>
      <h2>{this.props.post.userid}</h2>
      
      <button onClick= {()=>this.props.dispatch({type:"SEARCH_POST",id:this.props.post.id})}>Search Post</button>
    </div>
  );
 }
}
export default connect()(Post);